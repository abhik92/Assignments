package MainPackage;

public class PairLiveRange {
	public String first;
	public LiveRange second;

	public PairLiveRange(String A, LiveRange I) {
		this.first = A;
		this.second = I;
	}

}
