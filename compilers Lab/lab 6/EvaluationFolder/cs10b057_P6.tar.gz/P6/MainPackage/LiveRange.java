package MainPackage;

public class LiveRange {
	public Integer start;
	public Integer end;

}
