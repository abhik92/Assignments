package MainPackage;

public class Class {
	public String name;

	public Class(String name) {
		this.name = name;
	}
}
