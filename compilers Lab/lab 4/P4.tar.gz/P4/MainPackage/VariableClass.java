package MainPackage;

public class VariableClass {
	public String type;
	public String name;
	public int tempNumber;
	public int locationOfSize;
	
	public VariableClass(String type, String name, int tempNumber) {
		this.type = type;
		this.name = name;
		this.tempNumber = tempNumber;
	}

	public VariableClass() {

	}
}
